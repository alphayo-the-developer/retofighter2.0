const RUNNING = Symbol('running')
const SUCCESS = true
const FAILURE = false
