// import Node from './Node.js'

const Task = class  extends Node {
  nodeType = 'Task'
}
